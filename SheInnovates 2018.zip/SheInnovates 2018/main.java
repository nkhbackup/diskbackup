public class main
{
	
	//simulated login
	int userID = 4;
	int mentorOrMentee = 0; //mentor is 0 and mentee is 1
		
	//if it's in the other user's yes array, we put it into the user's match array (HAPPENS HERE)//
	
	//create server object that reads in file
	
	ConnectToServer server;
	
	//logic to match them to the user ID you logged in with (METHOD IN SERVER CLASS)
	Profile user = server.getMyProfile(4);
	
	//load relevant profile data for ID selected (METHOD IN SERVER CLASS)
	display(user);
	
	//****process and skip the ones you already matched with****
	Profile [] profilesToDownload = server.downloadProfiles(10);
	
	//create array of people who haven't interacted with you yet (METHOD IN SERVER CLASS)
	Profile [] profilesToMatchWith = user.filterOutPreviouslyMatched();
	
	//for each:
		
		//decide yes or no (HAPPENS HERE)
		//store this in the user's yes array (HAPPENS HERE)
		//if it's in the other user's yes array, we put it into the user's match array (HAPPENS HERE)

		for (Profile p: profilesToMatchWith)
		{
			if(decision)
			{
				user.storeInFavorites(p);
			}
			//updates both matchedProfiles and the server
			if(p.findProfileInFavorites(user))
			{
				user.
			}
		}
			
		
		
		
	//display matches

	//end

	
	
	
}