//hi i'm Navdeep Handa and get ready for a semester of sassy comments because i have to keep myself entertained somehow and this is all i have right now so just let me have it

//the course is CS 0401. i have class on Tuesday and Thursday from 1-2:15. this program simulates a shopping experience on command line, whose inputs are error-checked via various parameters.
import java.util.Scanner;
import java.io.PrintStream;

public class assignment1
{
	public static void main (String [] args)
	{
		//running the whole program again: setup
		int runagain=1;
		
		while(runagain==1)
		{			
		
		//me declaring a whole bunch of variables at the top bc might as well git 'er all done now
		
		int housepinsgryffindor=0, housepinsgryffindortotal=0, housepinsravenclaw=0,housepinsravenclawtotal=0, housepinshufflepuff=0, housepinshufflepufftotal=0, housepinsslytherin=0, housepinsslytherintotal=0, quaffle=0, quaffletotal=0, quaffleboxtotal=0, broomkit=0, broomkitstotal=0, subtotal=0, discount=0;
		
		//welcome to my s***show of a program		
		System.out.println("Welcome to Quality Quidditch Supplies [in a new n' convenient location in Hogsmeade just 4 u :)] \nAre you waiting for service? Type 1 if you are, and type 2 if you aren't.");
		
		Scanner sc = new Scanner(System.in);
		int wait=sc.nextInt();
		
		//error check for input bc humans suck. any loop with this format is an error check. i'm not commenting every single one because that'd take a year
		
		while(wait!=1&&wait!=2)
		{
			System.out.println("Just type 1 or 2. Not that hard: ");
			wait=sc.nextInt();
		}
		
		if(wait==2)
		{
			System.out.println("Sayonara!");
			System.exit(0);
		}
		
		//password time!
		System.out.println("What's the password yo ");
		String password=sc.next();

		//the route of champions ;) ;)
		String correctpassword="harryHOTTeramiright";
		if(password.equals(correctpassword))
		{
			System.out.println("What's up, Dumbledore's Army member?");
			reducedpricelist();
			
			System.out.println("Let our journey into the abyss of consumerism begin.");
			availableactionsmenu();
			
			int chooseaction=sc.nextInt();
			
			while(chooseaction<1||chooseaction>5)
			{
				System.out.println("Type an integer 1 through 5! Get it together, bud: ");
				chooseaction=sc.nextInt();
			}
			
			while(chooseaction!=5)
			{
			switch(chooseaction)
			{
				case 1:  
					//
						
					{System.out.println("Please choose an option:");
					System.out.println("\t1. Gryffindor");
					System.out.println("\t2. Slytherin");
					System.out.println("\t3. Ravenclaw");
					System.out.println("\t4. Hufflepuff");
					System.out.println("\t5. I'm done with the pins yo");
					
					int whichhouse=sc.nextInt();
					while(whichhouse<1||whichhouse>5)
					{
						System.out.println("Type an integer 1 through 5! Get it together, bud: ");
						whichhouse=sc.nextInt();
					}
					
					while(whichhouse!=5)
					{
						switch(whichhouse)
						{
							case 1:
								//Slytherin
								System.out.println("How many Gryffindor pins would you like?");
								housepinsgryffindor=sc.nextInt();
								housepinsgryffindortotal=housepinsgryffindortotal+housepinsgryffindor;
								if(housepinsgryffindortotal<0)
								{
									housepinsgryffindortotal=0;
									System.out.println("The negative number you entered was greater than the current total of items you have. Not my problem that you can't do math, but we're just gonna assume you meant to make your item total 0.");
								}
								break;
				
							case 2:
								//Slytherin
								System.out.println("How many Slytherin pins would you like?");
								housepinsslytherin=sc.nextInt();
								housepinsslytherintotal=housepinsslytherintotal+housepinsslytherin;
								if(housepinsslytherintotal<0)
								{
									housepinsslytherintotal=0;
									System.out.println("The negative number you entered was greater than the current total of items you have. Not my problem that you can't do math, but we're just gonna assume you meant to make your item total 0.");
								}
								break;
				
							case 3:
								//Ravenclaw
								System.out.println("How many Ravenclaw pins would you like?");
								housepinsravenclaw=sc.nextInt();
								housepinsravenclawtotal=housepinsravenclawtotal+housepinsravenclaw;
								if(housepinsravenclawtotal<0)
								{
									housepinsravenclawtotal=0;
									System.out.println("The negative number you entered was greater than the current total of items you have. Not my problem that you can't do math, but we're just gonna assume you meant to make your item total 0.");
								}
								break;
						
							case 4:
								//Hufflepuff
								System.out.println("How many Hufflepuff pins would you like?");
								housepinshufflepuff=sc.nextInt();
								housepinshufflepufftotal=housepinshufflepufftotal+housepinshufflepuff;
								if(housepinshufflepufftotal<0)
								{
									housepinshufflepufftotal=0;
									System.out.println("The negative number you entered was greater than the current total of items you have. Not my problem that you can't do math, but we're just gonna assume you meant to make your item total 0.");
								}
								break;
						
							case 5:
								break;
						}
					displaycurrentorder(housepinsgryffindortotal, housepinshufflepufftotal, housepinsravenclawtotal, housepinsslytherintotal, quaffletotal,quaffleboxtotal, broomkitstotal);
					
					System.out.println("Please choose an option:");
					System.out.println("\t1. Gryffindor");
					System.out.println("\t2. Slytherin");
					System.out.println("\t3. Ravenclaw");
					System.out.println("\t4. Hufflepuff");
					System.out.println("\t5. I'm done with the pins yo");
					
					whichhouse=sc.nextInt();

					while(whichhouse<1||whichhouse>5)
					{
						System.out.println("Type an integer 1 through 5! Get it together, bud: ");
						whichhouse=sc.nextInt();
					}
					}
					break;
					}
				
				case 2:
					//
					{
						System.out.println("How many quaffles would you like? (Please, only the total number. Management has weird rules lol)");
						quaffle=sc.nextInt();
						
						quaffleboxtotal=quaffle/5;
						quaffletotal=quaffle-(quaffleboxtotal*5);
						
						if(quaffleboxtotal<0)
							{
								quaffleboxtotal=0;
								System.out.println("The negative number you entered was greater than the current total of items you have. Not my problem that you can't do math, but we're just gonna assume you meant to make your item total 0.");
							}
						
						break;
						
					}
				
				case 3:
					//
					{
						System.out.println("How many broom service kits would you like?");
						broomkit=sc.nextInt();
						broomkitstotal=broomkit+broomkitstotal;
						
						if(broomkitstotal<0)
							{
							broomkitstotal=0;
							System.out.println("The negative number you entered was greater than the current total of items you have. Not my problem that you can't do math, but we're just gonna assume you meant to make your item total 0.");
							}
						
						break;
						
					}
				
				case 4:
					//
					{
						reducedpricelist();
						break;
					}
				
				case 5:
					//
					{
						break;
					}
			}
			
			displaycurrentorder(housepinsgryffindortotal, housepinshufflepufftotal,housepinsravenclawtotal, housepinsslytherintotal, quaffletotal,quaffleboxtotal, broomkitstotal);

			availableactionsmenu();
			chooseaction=sc.nextInt();
			
			while(chooseaction<1||chooseaction>5)
			{
				System.out.println("Type an integer 1 through 5! Get it together, bud: ");
				chooseaction=sc.nextInt();
			}
			
			}
			
			//checkout time!
			
			//checkout vars declaration: regular prices for pins. need to be declared because of the discount off 10+ doesn't accomodate <10. S H O C K E R
			int housepinsgryffindormoney=20*housepinsgryffindortotal, housepinsslytherinmoney=20*housepinsslytherintotal, housepinsravenclawmoney=20*housepinsravenclawtotal, housepinshufflepuffmoney=20*housepinshufflepufftotal;
			
			//checkout vars declaration: DD army prices (gotta get a discount for them double Ds amiright?)
			int housepinsgryffindorreducedmoney=18*housepinsgryffindortotal, housepinsslytherinreducedmoney=18*housepinsslytherintotal, housepinsravenclawreducedmoney=18*housepinsravenclawtotal, housepinshufflepuffreducedmoney=18*housepinshufflepufftotal, quafflemoney=quaffletotal*145, quaffleboxreducedmoney=580*quaffleboxtotal, broomkitsreducedmoney=899*broomkitstotal;
			
				
			System.out.println("Your current subtotal is:");
			if(housepinsgryffindortotal>0)
				{
					if(housepinsgryffindortotal+housepinshufflepufftotal+housepinsravenclawtotal+housepinsslytherintotal>10)
					{
						System.out.printf("\n\t %d%-50s %d%-50s",housepinsgryffindortotal," Gryffindor House pin(s) @ 18 Knuts each: ",housepinsgryffindorreducedmoney," Knuts");
					
					}
					else
					{
						System.out.printf("\n\t %d%-50s %d%-50s",housepinsgryffindortotal," Gryffindor House pin(s) @ 20 Knuts each: ",housepinsgryffindormoney," Knuts");
					
					}
				}
			if(housepinshufflepufftotal>0)
				{
					if(housepinsgryffindortotal+housepinshufflepufftotal+housepinsravenclawtotal+housepinsslytherintotal>10)
					{
						System.out.printf("\n\t %d%-50s %d%-50s",housepinshufflepufftotal," Hufflepuff House pin(s) @ 18 Knuts each: ",housepinshufflepuffreducedmoney," Knuts");
					
					}
					else
					{
						System.out.printf("\n\t %d%-50s %d%-50s",housepinshufflepufftotal," Hufflepuff House pin(s) @ 20 Knuts each: ",housepinshufflepuffmoney," Knuts");
					
					}				
				}
			if(housepinsravenclawtotal>0)
				{
					if(housepinsgryffindortotal+housepinshufflepufftotal+housepinsravenclawtotal+housepinsslytherintotal>10)
					{
						System.out.printf("\n\t %d%-50s %d%-50s",housepinsravenclawtotal," Ravenclaw House pin(s) @ 18 Knuts each: ",housepinsravenclawreducedmoney," Knuts");
					
					}
					else
					{
						System.out.printf("\n\t %d%-50s %d%-50s",housepinsravenclawtotal," Ravenclaw House pin(s) @ 20 Knuts each: ",housepinsravenclawmoney," Knuts");
					
					}			
				}
			if(housepinsslytherintotal>0)
				if(housepinsgryffindortotal+housepinshufflepufftotal+housepinsravenclawtotal+housepinsslytherintotal>10)
					{
						System.out.printf("\n\t %d%-50s %d%-50s",housepinsslytherintotal," Slytherin House pin(s) @ 18 Knuts each: ",housepinsslytherinreducedmoney," Knuts");
					
					}
					else
					{
						System.out.printf("\n\t %d%-50s %d%-50s",housepinsgryffindortotal," Slytherin House pin(s) @ 20 Knuts each: ",housepinsslytherinmoney," Knuts");
					
					}
			if(quaffletotal>0)
				{
					System.out.printf("\n\t %d%-50s %d%-50s",quaffletotal," Quaffle(s) @ 145 Knuts each: ",quafflemoney," Knuts");
				}
			if(quaffleboxtotal>0)
				{
					System.out.printf("\n\t %d%-50s %d%-50s",quaffleboxtotal," Box(es) of Quaffles @ 580 Knuts each: ",quaffleboxreducedmoney," Knuts");
				}
			if(broomkitstotal>0)
				{
				System.out.printf("\n\t %d%-50s %d%-50s",broomkitstotal," Broomstick Kit(s) @899 Knuts each: ",broomkitsreducedmoney," Knuts");
				}
			
			if(housepinsgryffindortotal+housepinshufflepufftotal+housepinsravenclawtotal+housepinsslytherintotal>10)
			{
				subtotal=housepinsgryffindorreducedmoney+housepinsslytherinreducedmoney+housepinsravenclawreducedmoney+housepinshufflepuffreducedmoney+quafflemoney+quaffleboxreducedmoney+broomkitsreducedmoney;
				
				if(subtotal>=1479)
				{
					
					discount=(int)(0.1*subtotal);
					subtotal=subtotal-discount;
					System.out.printf("\n\t %-50s %d%-50s\n\n"," 10% discount since your order is 3 Galleons or above: -",discount," Knuts");
				}
				
				else
				{
					System.out.printf("\n\t %-50s %d%-50s\n\n","Your total is: ",subtotal," Knuts");
				}
					
			}
			else
			{
				subtotal=housepinsgryffindormoney+housepinsslytherinmoney+housepinsravenclawmoney+housepinshufflepuffmoney+quafflemoney+quaffleboxreducedmoney+broomkitsreducedmoney;
				
				if(subtotal>=1479)
				{
					discount=(int)(0.1*subtotal);
					subtotal=subtotal-discount;
					System.out.printf("\n\t %-50s %d%-50s\n\n"," 10% discount since your order is 3 Galleons or above: -",discount," Knuts");
					System.out.printf("\n\t %-50s %d%-50s\n\n","Your total is: ",subtotal," Knuts");
				}
				
				else
				{
					System.out.printf("\n\t %-50s %d%-50s\n\n","Your total is: ",subtotal," Knuts");
				}
			}
			
			//the part with the Benjamins #dolladollabills
			if(subtotal>0)
			{
			askforpayment();
			
			
			//takes all the payments and converts them to knuts before adding together
			
			int paymenttotal=0, amountremaining=subtotal;
			
			int payment;
			String currency;
			
			while(paymenttotal<subtotal)
			{
				System.out.println("Enter payment here: ");
				payment=sc.nextInt();
				currency=sc.next();
				
				while(payment<0 || (!currency.equals("Knuts")&&!currency.equals("Knut")&&!currency.equals("Sickles")&&!currency.equals("Sickle")&&!currency.equals("Galleons")&&!currency.equals("Galleon")))
				{
					System.out.println("Invalid input. Please reenter and PLEASSEEE, try not to make my life so hard:");
					payment=sc.nextInt();
					currency=sc.next();
				}
				
				if(currency.equals("Knuts")||currency.equals("Knut"))
				{
					paymenttotal=payment+paymenttotal;
					amountremaining=subtotal-paymenttotal;
					if(amountremaining>0)
					{
						System.out.println("You have paid "+payment+" Knuts. You still owe "+amountremaining+" Knuts.");
					}
					
				}
				if(currency.equals("Sickles")||currency.equals("Sickle"))
				{
					paymenttotal=payment*29+paymenttotal;
					amountremaining=subtotal-paymenttotal;
					if(amountremaining>0)
					{
						System.out.println("You have paid "+payment+" Sickles. You still owe "+amountremaining+" Knuts.");
					}
				}
				if(currency.equals("Galleons")||currency.equals("Galleon"))
				{
					paymenttotal=payment*493+paymenttotal;
					amountremaining=subtotal-paymenttotal;
					if(amountremaining>0)
					{
						System.out.println("You have paid "+payment+" Galleons. You still owe "+amountremaining+" Knuts.");
					}
					
				}
				
			}
			
			//change calculator. the absolute value of amountremaining will give the correct number of knuts of change, since amountremaining decrements in the loop before the condition that terminates the loop can be checked.
			
			int changeinknuts;
			changeinknuts=Math.abs(amountremaining);

			int galleons=0;
			int sickles=0;
			
			galleons=changeinknuts/493;
			changeinknuts=changeinknuts-galleons*493;
			
			sickles=changeinknuts/29;
			changeinknuts=changeinknuts-sickles*29;
			
			System.out.println("Here is your change:");
			System.out.println("\t"+galleons+" Galleon(s)");
			System.out.println("\t"+sickles+" Sickle(s)");
			System.out.println("\t"+changeinknuts+" Knut(s)");
			System.out.println("Have a good one! Or don't, I don't care.");
		}
		else
			{
				System.out.println("Just passing through? Oh well, have a nice day! JK");
			}
		}		
		
		

		else
		{
			System.out.println("YOU WRONG. TRY AGAIN: ");
			password=sc.next();
			
			//the route for people who can't type things (@me)
			if(password.equals(correctpassword))
			{
			System.out.println("What's up, Dumbledore's Army member?");
			reducedpricelist();
			
			System.out.println("Let our journey into the abyss of consumerism begin.");
			availableactionsmenu();
			
			int chooseaction=sc.nextInt();
			
			while(chooseaction<1||chooseaction>5)
			{
				System.out.println("Type an integer 1 through 5! Get it together, bud: ");
				chooseaction=sc.nextInt();
			}
			
			while(chooseaction!=5)
			{
			switch(chooseaction)
			{
				case 1:  
					//
						
					{System.out.println("Please choose an option:");
					System.out.println("\t1. Gryffindor");
					System.out.println("\t2. Slytherin");
					System.out.println("\t3. Ravenclaw");
					System.out.println("\t4. Hufflepuff");
					System.out.println("\t5. I'm done with the pins yo");
					
					int whichhouse=sc.nextInt();
					while(whichhouse<1||whichhouse>5)
					{
						System.out.println("Type an integer 1 through 5! Get it together, bud: ");
						whichhouse=sc.nextInt();
					}
					
					while(whichhouse!=5)
					{
						switch(whichhouse)
						{
							case 1:
								//Slytherin
								System.out.println("How many Gryffindor pins would you like?");
								housepinsgryffindor=sc.nextInt();
								housepinsgryffindortotal=housepinsgryffindortotal+housepinsgryffindor;
								if(housepinsgryffindortotal<0)
								{
									housepinsgryffindortotal=0;
									System.out.println("The negative number you entered was greater than the current total of items you have. Not my problem that you can't do math, but we're just gonna assume you meant to make your item total 0.");
								}
								break;
				
							case 2:
								//Slytherin
								System.out.println("How many Slytherin pins would you like?");
								housepinsslytherin=sc.nextInt();
								housepinsslytherintotal=housepinsslytherintotal+housepinsslytherin;
								if(housepinsslytherintotal<0)
								{
									housepinsslytherintotal=0;
									System.out.println("The negative number you entered was greater than the current total of items you have. Not my problem that you can't do math, but we're just gonna assume you meant to make your item total 0.");
								}
								break;
				
							case 3:
								//Ravenclaw
								System.out.println("How many Ravenclaw pins would you like?");
								housepinsravenclaw=sc.nextInt();
								housepinsravenclawtotal=housepinsravenclawtotal+housepinsravenclaw;
								if(housepinsravenclawtotal<0)
								{
									housepinsravenclawtotal=0;
									System.out.println("The negative number you entered was greater than the current total of items you have. Not my problem that you can't do math, but we're just gonna assume you meant to make your item total 0.");
								}
								break;
						
							case 4:
								//Hufflepuff
								System.out.println("How many Hufflepuff pins would you like?");
								housepinshufflepuff=sc.nextInt();
								housepinshufflepufftotal=housepinshufflepufftotal+housepinshufflepuff;
								if(housepinshufflepufftotal<0)
								{
									housepinshufflepufftotal=0;
									System.out.println("The negative number you entered was greater than the current total of items you have. Not my problem that you can't do math, but we're just gonna assume you meant to make your item total 0.");
								}
								break;
						
							case 5:
								break;
						}
					displaycurrentorder(housepinsgryffindortotal, housepinshufflepufftotal, housepinsravenclawtotal, housepinsslytherintotal, quaffletotal,quaffleboxtotal, broomkitstotal);
					
					System.out.println("Please choose an option:");
					System.out.println("\t1. Gryffindor");
					System.out.println("\t2. Slytherin");
					System.out.println("\t3. Ravenclaw");
					System.out.println("\t4. Hufflepuff");
					System.out.println("\t5. I'm done with the pins yo");
					
					whichhouse=sc.nextInt();

					while(whichhouse<1||whichhouse>5)
					{
						System.out.println("Type an integer 1 through 5! Get it together, bud: ");
						whichhouse=sc.nextInt();
					}
					}
					break;
					}
				
				case 2:
					//
					{
						System.out.println("How many quaffles would you like? (Please, only the total number. Management has weird rules lol)");
						quaffle=sc.nextInt();
						
						quaffleboxtotal=quaffle/5;
						quaffletotal=quaffle-(quaffleboxtotal*5);
						
						if(quaffleboxtotal<0)
							{
								quaffleboxtotal=0;
								System.out.println("The negative number you entered was greater than the current total of items you have. Not my problem that you can't do math, but we're just gonna assume you meant to make your item total 0.");
							}
						
						break;
						
					}
				
				case 3:
					//
					{
						System.out.println("How many broom service kits would you like?");
						broomkit=sc.nextInt();
						broomkitstotal=broomkit+broomkitstotal;
						
						if(broomkitstotal<0)
							{
							broomkitstotal=0;
							System.out.println("The negative number you entered was greater than the current total of items you have. Not my problem that you can't do math, but we're just gonna assume you meant to make your item total 0.");
							}
						
						break;
						
					}
				
				case 4:
					//
					{
						reducedpricelist();
						break;
					}
				
				case 5:
					//
					{
						break;
					}
			}
			
			displaycurrentorder(housepinsgryffindortotal, housepinshufflepufftotal,housepinsravenclawtotal, housepinsslytherintotal, quaffletotal,quaffleboxtotal, broomkitstotal);

			availableactionsmenu();
			chooseaction=sc.nextInt();
			
			while(chooseaction<1||chooseaction>5)
			{
				System.out.println("Type an integer 1 through 5! Get it together, bud: ");
				chooseaction=sc.nextInt();
			}
			
			}
			
			//checkout time!
			
			//checkout vars declaration: regular prices for pins. need to be declared because of the discount off 10+ doesn't accomodate <10. S H O C K E R
			int housepinsgryffindormoney=20*housepinsgryffindortotal, housepinsslytherinmoney=20*housepinsslytherintotal, housepinsravenclawmoney=20*housepinsravenclawtotal, housepinshufflepuffmoney=20*housepinshufflepufftotal;
			
			//checkout vars declaration: DD army prices (gotta get a discount for them double Ds amiright?)
			int housepinsgryffindorreducedmoney=18*housepinsgryffindortotal, housepinsslytherinreducedmoney=18*housepinsslytherintotal, housepinsravenclawreducedmoney=18*housepinsravenclawtotal, housepinshufflepuffreducedmoney=18*housepinshufflepufftotal, quafflemoney=quaffletotal*145, quaffleboxreducedmoney=580*quaffleboxtotal, broomkitsreducedmoney=899*broomkitstotal;
			
				
			System.out.println("Your current subtotal is:");
			if(housepinsgryffindortotal>0)
				{
					if(housepinsgryffindortotal+housepinshufflepufftotal+housepinsravenclawtotal+housepinsslytherintotal>10)
					{
						System.out.printf("\n\t %d%-50s %d%-50s",housepinsgryffindortotal," Gryffindor House pin(s) @ 18 Knuts each: ",housepinsgryffindorreducedmoney," Knuts");
					
					}
					else
					{
						System.out.printf("\n\t %d%-50s %d%-50s",housepinsgryffindortotal," Gryffindor House pin(s) @ 20 Knuts each: ",housepinsgryffindormoney," Knuts");
					
					}
				}
			if(housepinshufflepufftotal>0)
				{
					if(housepinsgryffindortotal+housepinshufflepufftotal+housepinsravenclawtotal+housepinsslytherintotal>10)
					{
						System.out.printf("\n\t %d%-50s %d%-50s",housepinshufflepufftotal," Hufflepuff House pin(s) @ 18 Knuts each: ",housepinshufflepuffreducedmoney," Knuts");
					
					}
					else
					{
						System.out.printf("\n\t %d%-50s %d%-50s",housepinshufflepufftotal," Hufflepuff House pin(s) @ 20 Knuts each: ",housepinshufflepuffmoney," Knuts");
					
					}				
				}
			if(housepinsravenclawtotal>0)
				{
					if(housepinsgryffindortotal+housepinshufflepufftotal+housepinsravenclawtotal+housepinsslytherintotal>10)
					{
						System.out.printf("\n\t %d%-50s %d%-50s",housepinsravenclawtotal," Ravenclaw House pin(s) @ 18 Knuts each: ",housepinsravenclawreducedmoney," Knuts");
					
					}
					else
					{
						System.out.printf("\n\t %d%-50s %d%-50s",housepinsravenclawtotal," Ravenclaw House pin(s) @ 20 Knuts each: ",housepinsravenclawmoney," Knuts");
					
					}			
				}
			if(housepinsslytherintotal>0)
				if(housepinsgryffindortotal+housepinshufflepufftotal+housepinsravenclawtotal+housepinsslytherintotal>10)
					{
						System.out.printf("\n\t %d%-50s %d%-50s",housepinsslytherintotal," Slytherin House pin(s) @ 18 Knuts each: ",housepinsslytherinreducedmoney," Knuts");
					
					}
					else
					{
						System.out.printf("\n\t %d%-50s %d%-50s",housepinsgryffindortotal," Slytherin House pin(s) @ 20 Knuts each: ",housepinsslytherinmoney," Knuts");
					
					}
			if(quaffletotal>0)
				{
					System.out.printf("\n\t %d%-50s %d%-50s",quaffletotal," Quaffle(s) @ 145 Knuts each: ",quafflemoney," Knuts");
				}
			if(quaffleboxtotal>0)
				{
					System.out.printf("\n\t %d%-50s %d%-50s",quaffleboxtotal," Box(es) of Quaffles @ 580 Knuts each: ",quaffleboxreducedmoney," Knuts");
				}
			if(broomkitstotal>0)
				{
				System.out.printf("\n\t %d%-50s %d%-50s",broomkitstotal," Broomstick Kit(s) @899 Knuts each: ",broomkitsreducedmoney," Knuts");
				}
			
			if(housepinsgryffindortotal+housepinshufflepufftotal+housepinsravenclawtotal+housepinsslytherintotal>10)
			{
				subtotal=housepinsgryffindorreducedmoney+housepinsslytherinreducedmoney+housepinsravenclawreducedmoney+housepinshufflepuffreducedmoney+quafflemoney+quaffleboxreducedmoney+broomkitsreducedmoney;
				
				if(subtotal>=1479)
				{
					discount=(int)(0.1*subtotal);
					subtotal=subtotal-discount;
					System.out.printf("\n\t %-50s %d%-50s\n\n"," 10% discount since your order is 3 Galleons or above: -",discount," Knuts");
					System.out.printf("\n\t %-50s %d%-50s\n\n","Your total is: ",subtotal," Knuts");
				}
				
				else
				{
					System.out.printf("\n\t %-50s %d%-50s\n\n","Your total is: ",subtotal," Knuts");
				}
					
			}
			else
			{
				subtotal=housepinsgryffindormoney+housepinsslytherinmoney+housepinsravenclawmoney+housepinshufflepuffmoney+quafflemoney+quaffleboxreducedmoney+broomkitsreducedmoney;
				System.out.printf("\n\t %-50s %d%-50s\n\n","Your total is: ",subtotal," Knuts");
				
				if(subtotal>=1479)
				{
					discount=(int)(0.1*subtotal);
					subtotal=subtotal-discount;
					System.out.printf("\n\t %-50s %d%-50s\n\n"," 10% discount since your order is 3 Galleons or above: -",discount," Knuts");
				}
				
				else
				{
					System.out.printf("\n\t %-50s %d%-50s\n\n","Your total is: ",subtotal," Knuts");
				}
			}
			
			//the part with the Benjamins #dolladollabills
			if(subtotal>0)
			{
			askforpayment();
			
			
			//takes all the payments and converts them to knuts before adding together
			
			int paymenttotal=0, amountremaining=subtotal;
			
			int payment;
			String currency;
			
			while(paymenttotal<subtotal)
			{
				System.out.println("Enter payment here: ");
				payment=sc.nextInt();
				currency=sc.next();
				
				while(payment<0 || (!currency.equals("Knuts")&&!currency.equals("Knut")&&!currency.equals("Sickles")&&!currency.equals("Sickle")&&!currency.equals("Galleons")&&!currency.equals("Galleon")))
				{
					System.out.println("Invalid input. Please reenter and PLEASSEEE, try not to make my life so hard:");
					payment=sc.nextInt();
					currency=sc.next();
				}
				
				if(currency.equals("Knuts")||currency.equals("Knut"))
				{
					paymenttotal=payment+paymenttotal;
					amountremaining=subtotal-paymenttotal;
					if(amountremaining>0)
					{
						System.out.println("You have paid "+payment+" Knuts. You still owe "+amountremaining+" Knuts.");
					}
					
				}
				if(currency.equals("Sickles")||currency.equals("Sickle"))
				{
					paymenttotal=payment*29+paymenttotal;
					amountremaining=subtotal-paymenttotal;
					if(amountremaining>0)
					{
						System.out.println("You have paid "+payment+" Sickles. You still owe "+amountremaining+" Knuts.");
					}
				}
				if(currency.equals("Galleons")||currency.equals("Galleon"))
				{
					paymenttotal=payment*493+paymenttotal;
					amountremaining=subtotal-paymenttotal;
					if(amountremaining>0)
					{
						System.out.println("You have paid "+payment+" Galleons. You still owe "+amountremaining+" Knuts.");
					}
					
				}
				
			}
			
			//change calculator. the absolute value of amountremaining will give the correct number of knuts of change, since amountremaining decrements in the loop before the condition that terminates the loop can be checked.
			
			int changeinknuts;
			changeinknuts=Math.abs(amountremaining);

			int galleons=0;
			int sickles=0;
			
			galleons=changeinknuts/493;
			changeinknuts=changeinknuts-galleons*493;
			
			sickles=changeinknuts/29;
			changeinknuts=changeinknuts-sickles*29;
			
			System.out.println("Here is your change:");
			System.out.println("\t"+galleons+" Galleon(s)");
			System.out.println("\t"+sickles+" Sickle(s)");
			System.out.println("\t"+changeinknuts+" Knut(s)");
			System.out.println("Have a good one! Or don't, I don't care.");
		}
		else
			{
				System.out.println("Just passing through? Oh well, have a nice day! JK");
			}
			}
			
			//the LOSER route!
			else
			{
				System.out.println("I guess you don't like saving. Join Dumbledore's Army today and escape the tyranny of regular prices! Anyway, go on with it. We'll let you shop.");
			regularpricelist();
			
			System.out.println("Let our journey into the abyss of consumerism begin.");
			availableactionsmenu();
			
			int chooseaction=sc.nextInt();
			
			while(chooseaction<1||chooseaction>5)
			{
				System.out.println("Type an integer 1 through 5! Get it together, bud: ");
				chooseaction=sc.nextInt();
			}
			
			while(chooseaction!=5)
			{
			switch(chooseaction)
			{
				case 1:  
					//
						
					{System.out.println("Please choose an option:");
					System.out.println("\t1. Gryffindor");
					System.out.println("\t2. Slytherin");
					System.out.println("\t3. Ravenclaw");
					System.out.println("\t4. Hufflepuff");
					System.out.println("\t5. I'm done with the pins yo");
					
					int whichhouse=sc.nextInt();
					
					while(whichhouse<1||whichhouse>5)
					{
						System.out.println("Type an integer 1 through 5! Get it together, bud: ");
						whichhouse=sc.nextInt();
					}
					
					while(whichhouse!=5)
					{
						switch(whichhouse)
						{
							case 1:
								//Slytherin
								System.out.println("How many Gryffindor pins would you like?");
								housepinsgryffindor=sc.nextInt();
								housepinsgryffindortotal=housepinsgryffindortotal+housepinsgryffindor;
								if(housepinsgryffindortotal<0)
								{
									housepinsgryffindortotal=0;
									System.out.println("The negative number you entered was greater than the current total of items you have. Not my problem that you can't do math, but we're just gonna assume you meant to make your item total 0.");
								}
								break;
				
							case 2:
								//Slytherin
								System.out.println("How many Slytherin pins would you like?");
								housepinsslytherin=sc.nextInt();
								housepinsslytherintotal=housepinsslytherintotal+housepinsslytherin;
								if(housepinsslytherintotal<0)
								{
									housepinsslytherintotal=0;
									System.out.println("The negative number you entered was greater than the current total of items you have. Not my problem that you can't do math, but we're just gonna assume you meant to make your item total 0.");
								}
								break;
				
							case 3:
								//Ravenclaw
								System.out.println("How many Ravenclaw pins would you like?");
								housepinsravenclaw=sc.nextInt();
								housepinsravenclawtotal=housepinsravenclawtotal+housepinsravenclaw;
								if(housepinsravenclawtotal<0)
								{
									housepinsravenclawtotal=0;
									System.out.println("The negative number you entered was greater than the current total of items you have. Not my problem that you can't do math, but we're just gonna assume you meant to make your item total 0.");
								}
								break;
						
							case 4:
								//Hufflepuff
								System.out.println("How many Hufflepuff pins would you like?");
								housepinshufflepuff=sc.nextInt();
								housepinshufflepufftotal=housepinshufflepufftotal+housepinshufflepuff;
								if(housepinshufflepufftotal<0)
								{
									housepinshufflepufftotal=0;
									System.out.println("The negative number you entered was greater than the current total of items you have. Not my problem that you can't do math, but we're just gonna assume you meant to make your item total 0.");
								}
								break;
						
							case 5:
								//
								
								break;
						}
					displaycurrentorder(housepinsgryffindortotal, housepinshufflepufftotal, housepinsravenclawtotal, housepinsslytherintotal, quaffletotal,quaffleboxtotal, broomkitstotal);
					
					System.out.println("Please choose an option:");
					System.out.println("\t1. Gryffindor");
					System.out.println("\t2. Slytherin");
					System.out.println("\t3. Ravenclaw");
					System.out.println("\t4. Hufflepuff");
					System.out.println("\t5. I'm done with the pins yo");
					
					whichhouse=sc.nextInt();
					
					while(whichhouse<1||whichhouse>5)
					{
						System.out.println("Type an integer 1 through 5! Get it together, bud: ");
						whichhouse=sc.nextInt();
					}
					
					}
					break;
					}
				
				case 2:
					//
					{
						System.out.println("How many quaffles would you like? (Please, only the total number. Management has weird rules lol)");
						quaffle=sc.nextInt();
						
						quaffleboxtotal=quaffle/5;
						quaffletotal=quaffle-(quaffleboxtotal*5);
						
						if(quaffleboxtotal<0)
							{
								quaffleboxtotal=0;
								System.out.println("The negative number you entered was greater than the current total of items you have. Not my problem that you can't do math, but we're just gonna assume you meant to make your item total 0.");
							}
						
						break;
						
					}
				
				case 3:
					//
					{
						System.out.println("How many broom service kits would you like?");
						broomkit=sc.nextInt();
						broomkitstotal=broomkit+broomkitstotal;
						
						if(broomkitstotal<0)
							{
							broomkitstotal=0;
							System.out.println("The negative number you entered was greater than the current total of items you have. Not my problem that you can't do math, but we're just gonna assume you meant to make your item total 0.");
							}
						
						break;
						
					}
				
				case 4:
					//
					{
						regularpricelist();
						break;
					}
				
				case 5:
					//
					{
						break;
					}
			}
			
			displaycurrentorder(housepinsgryffindortotal, housepinshufflepufftotal,housepinsravenclawtotal, housepinsslytherintotal, quaffletotal,quaffleboxtotal, broomkitstotal);

			availableactionsmenu();
			chooseaction=sc.nextInt();
			
			while(chooseaction<1||chooseaction>5)
			{
				System.out.println("Type an integer 1 through 5! Get it together, bud: ");
				chooseaction=sc.nextInt();
			}
			
			}
			
			//checkout time!
			
			//checkout vars declaration: regular prices
			
			int housepinsgryffindormoney=20*housepinsgryffindortotal, housepinsslytherinmoney=20*housepinsslytherintotal, housepinsravenclawmoney=20*housepinsravenclawtotal, housepinshufflepuffmoney=20*housepinshufflepufftotal, quafflemoney=quaffletotal*145, quaffleboxmoney=638*quaffleboxtotal, broomkitsmoney=986*broomkitstotal;
			
			System.out.println("Your current subtotal is:");
			if(housepinsgryffindortotal>0)
				{
					System.out.printf("\n\t %d%-50s %d%-50s",housepinsgryffindortotal," Gryffindor House pin(s) @ 20 Knuts each: ",housepinsgryffindormoney," Knuts");
				}
			if(housepinshufflepufftotal>0)
				{
					System.out.printf("\n\t %d%-50s %d%-50s",housepinshufflepufftotal," Hufflepuff House pin(s) @ 20 Knuts each: ",housepinshufflepuffmoney," Knuts");			
				}
			if(housepinsravenclawtotal>0)
				{
					System.out.printf("\n\t %d%-50s %d%-50s",housepinsravenclawtotal," Ravenclaw House pin(s) @ 20 Knuts each: ",housepinsravenclawmoney," Knuts");			
				}
			if(housepinsslytherintotal>0)
				if(housepinsgryffindortotal+housepinshufflepufftotal+housepinsravenclawtotal+housepinsslytherintotal>10)
				{
					System.out.printf("\n\t %d%-50s %d%-50s",housepinsgryffindortotal," Slytherin House pin(s) @ 20 Knuts each: ",housepinsslytherinmoney," Knuts");
				}
			if(quaffletotal>0)
				{
					System.out.printf("\n\t %d%-50s %d%-50s",quaffletotal," Quaffle(s) @ 145 Knuts each: ",quafflemoney," Knuts");
				}
			if(quaffleboxtotal>0)
				{
					System.out.printf("\n\t %d%-50s %d%-50s",quaffleboxtotal," Box(es) of Quaffles @ 580 Knuts each: ",quaffleboxmoney," Knuts");
				}
			if(broomkitstotal>0)
				{
				System.out.printf("\n\t %d%-50s %d%-50s",broomkitstotal," Broomstick Kit(s) @899 Knuts each: ",broomkitsmoney," Knuts");
				}
			
			subtotal=housepinsgryffindormoney+housepinsslytherinmoney+housepinsravenclawmoney+housepinshufflepuffmoney+quafflemoney+quaffleboxmoney+broomkitsmoney;
			System.out.printf("\n\t %-50s %d%-50s\n\n","Your total is: ",subtotal," Knuts");
					
			
			//the part with the Benjamins #dolladollabills
			
			if(subtotal>0)
			{
				
			askforpayment();
			
			
			//takes all the payments and converts them to knuts before adding together
			
			int paymenttotal=0, amountremaining=subtotal;
			
			int payment;
			String currency;
			
			while(paymenttotal<subtotal)
			{
				System.out.println("Enter payment here: ");
				payment=sc.nextInt();
				currency=sc.next();
				
				while(payment<0 || (!currency.equals("Knuts")&&!currency.equals("Knut")&&!currency.equals("Sickles")&&!currency.equals("Sickle")&&!currency.equals("Galleons")&&!currency.equals("Galleon")))
				{
					System.out.println("Invalid input. Please reenter and PLEASSEEE, try not to make my life so hard:");
					payment=sc.nextInt();
					currency=sc.next();
				}
				
				if(currency.equals("Knuts")||currency.equals("Knut"))
				{
					paymenttotal=payment+paymenttotal;
					amountremaining=subtotal-paymenttotal;
					if(amountremaining>0)
					{
						System.out.println("You have paid "+payment+" Knuts. You still owe "+amountremaining+" Knuts.");
					}
					
				}
				if(currency.equals("Sickles")||currency.equals("Sickle"))
				{
					paymenttotal=payment*29+paymenttotal;
					amountremaining=subtotal-paymenttotal;
					if(amountremaining>0)
					{
						System.out.println("You have paid "+payment+" Sickles. You still owe "+amountremaining+" Knuts.");
					}
				}
				if(currency.equals("Galleons")||currency.equals("Galleon"))
				{
					paymenttotal=payment*493+paymenttotal;
					amountremaining=subtotal-paymenttotal;
					if(amountremaining>0)
					{
						System.out.println("You have paid "+payment+" Galleons. You still owe "+amountremaining+" Knuts.");
					}
					
				}
			
			
				
			}
			
			
			
			//change calculator. the absolute value of amountremaining will give the correct number of knuts of change, since amountremaining decrements in the loop before the condition that terminates the loop can be checked.
			
			int changeinknuts;
			changeinknuts=Math.abs(amountremaining);

			int galleons=0;
			int sickles=0;
			
			galleons=changeinknuts/493;
			changeinknuts=changeinknuts-galleons*493;
			
			sickles=changeinknuts/29;
			changeinknuts=changeinknuts-sickles*29;
			
			System.out.println("Here is your change:");
			System.out.println("\t"+galleons+" Galleon(s)");
			System.out.println("\t"+sickles+" Sickle(s)");
			System.out.println("\t"+changeinknuts+" Knut(s)");
			System.out.println("Have a good one! Or don't, I don't care.");
				
			}
			
			else
			{
				System.out.println("Just passing through? Oh well, have a nice day! JK");
			}
			
			}
		}
		
		//would they like to run it again
		System.out.println("Would you like to repeat the program? Type 1 for yes and 2 for no: ");
		runagain=sc.nextInt();
		}
		
	}
		
	//methods that really didn't need to be written but were simply written for my own sanity when i went back to read through the code
	
	public static void regularpricelist()
	{
		//price list
		System.out.println("Here is our price list:");
		System.out.printf("\n\t%-70s %-70s","-House Pins (each):","20 Knuts");
		System.out.printf("\n\t%-70s","Available in Gryffindor, Slytherin, Hufflepuff, and Ravenclaw\n");
		System.out.printf("\n\t%-70s %-70s","-Quaffles (each):","145 Knuts");
		System.out.printf("\n\t%-70s %-70s","-Quaffles (box):","638 Knuts");
		System.out.printf("\n\t%-70s %-70s\n\n","-Broomstick Service Kits (each):","986 Knuts");
	}

	public static void reducedpricelist()
	{
		//price list
		System.out.println("Here is our price list:");
		System.out.printf("\n\t%-70s %-70s","-House Pins (each):","20 Knuts, or 18 Knuts when you purchase 10 or more");
		System.out.printf("\n\t%-70s","Available in Gryffindor, Slytherin, Hufflepuff, and Ravenclaw");
		System.out.printf("\n\t%-70s %-70s","-Quaffles (each):","145 Knuts");
		System.out.printf("\n\t%-70s %-70s","-Quaffles (box):","580 Knuts");
		System.out.printf("\n\t%-70s %-70s","-Broomstick Service Kits (each):","899 Knuts");
		System.out.printf("\n\t%-70s\n\n","-Additional 10% for any order of 3 Galleons or more");
	}
	
	public static void availableactionsmenu()
	{
		//available actions menu
		System.out.println("\nSome rules: if you decide to add more to an order, reselect that option on the menu and order the number you wish to add. If you ordered too many and want to remove sum, add the number you want to remove as a negative number. The program will automatically update to reflect these changes. For example, if I ordered 8 pins and wanted to order 4 more, I'd go back through the pin menu and select 4 of the pins as an additional order. Or if I wanted to remove 4, I'd order -4 pins.\n");
		System.out.println("Please choose an option:");
		System.out.println("\t1. Update House Pins Order");
		System.out.println("\t2. Update Quaffles Order");
		System.out.println("\t3. Update Broomstick Kits Order");
		System.out.println("\t4. Show price list");
		System.out.println("\t5. Check out and get outta this joint");
	}

	public static void displaycurrentorder(int housepinsgryffindortotal, int housepinshufflepufftotal, int housepinsravenclawtotal, int housepinsslytherintotal, int quaffletotal, int quaffleboxtotal, int broomkitstotal)
	{
		System.out.println("Your current order is:");
		if(housepinsgryffindortotal>0)
			{System.out.println("\t"+housepinsgryffindortotal+" Gryffindor House pin(s)");}
		if(housepinshufflepufftotal>0)
			{System.out.println("\t"+housepinshufflepufftotal+" Hufflepuff House pin(s)");}
		if(housepinsravenclawtotal>0)
			{System.out.println("\t"+housepinsravenclawtotal+" Ravenclaw House pin(s)");}
		if(housepinsslytherintotal>0)
			{System.out.println("\t"+housepinsslytherintotal+" Slytherin House pin(s)");}
		if(quaffletotal>0)
			{System.out.println("\t"+quaffletotal+" Quaffle(s)");}
		if(quaffleboxtotal>0)
			{System.out.println("\t"+quaffleboxtotal+" Box(es) of Quaffles");}
		if(broomkitstotal>0)
			{System.out.println("\t"+broomkitstotal+" Broomstick Kit(s)");}
			
	}
	
	public static void askforpayment()
	{
		System.out.println("Please pay us. We'd prefer if you do it in the following format:");
			System.out.println("<amount><space><currency>");
			System.out.println("\tWhere <amount> is an integer");
			System.out.println("\tWhere <space> is a blank space");
			System.out.println("\tWhere <currency> is either Knuts, Sickles, or Galleons");
			System.out.println("Enter as many times as you'd like. You can keep entering until the amount you have paid is greater than or equal to your bill.");
			System.out.println("Note 1: We appreciate exact change.\n\n Note 2: For the not-so-bright of y'all, here's a currency exchange chart:");
			System.out.println("\t 29 Knuts = 1 Sickle\n\t493 Knuts = 1 Sickle = 1 Galleon");
	}
}